# TooManySuits

Installation
-

- Install BepInEx.
- Download and install More Suits.
- Download and install TooManySuits.

Default Controls
-

- Next Page: n
- Back Page: b

These are configurable in the config, located at Lethal Company\BepInEx\config\verity.TooManySuits.cfg

Changelogs
-

### Version 1.0.1
- Fixed text, it now disappears when exiting the ship.
- Text is now moved to a more convenient place.

### Version 1.0.2
- Text is now hovering above the clothing rack, instead of being a UI element.

### Version 1.0.3
- Editable Text-Scale in the config.

### Version 1.0.4
- Bug fixes

### Version 1.0.5
- Visual bug reported by and fixed by Lordfirespeed (off-by-one error)
- Game breaking bug caused by page number not being reset when disconnecting or being kicked, reported by Clark (https://thunderstore.io/c/lethal-company/p/TeamClark/TheMostLethalCompany/)