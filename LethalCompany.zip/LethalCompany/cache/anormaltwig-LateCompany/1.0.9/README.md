# LateCompany

Lets players join you after the game has started.

If the in-game invite menu is not working, then the steam overlay menu should work for inviting your friends!

## Info

Please report any bugs you find on the github repository!

## Changelogs

### V1.0.9

- Fixed weather desync. (Probably)
- Code cleanup.
- Changed a config name and description. You will probably have to remove the old .cfg file for this mod.

